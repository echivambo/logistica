@extends('layouts.pag')

@section('content')

    <!-- One -->
    <section id="one" class="wrapper style1 special">
        <div class="inner">
            <header class="major">
                <h2>Arcu aliquet vel lobortis ata nisl<br />
                    eget augue amet aliquet nisl cep donec</h2>
                <p>Aliquam ut ex ut augue consectetur interdum. Donec amet imperdiet eleifend<br />
                    fringilla tincidunt. Nullam dui leo Aenean mi ligula, rhoncus ullamcorper.</p>
            </header>
            <form class="row">
                <div class="input-field col s4 offset-s4">
                    <input id="input_text" type="text" data-length="10" placeholder="_ _ _ _ _ _">
                    <label for="input_text">Digite o código de confirmação</label>
                </div>

            </form>
        </div>
    </section>

</div>

@endsection