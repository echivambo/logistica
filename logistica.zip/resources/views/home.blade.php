@extends('admin.layout')
@section('content')

    <!-- Page Content -->

            <div class="row bg-title">
                <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                    <h4 class="page-title">Dashboard</h4> </div>
                <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12"> <a href="http://wrappixel.com/templates/pixeladmin/" target="_blank" class="btn btn-danger pull-right m-l-20 btn-rounded btn-outline hidden-xs hidden-sm waves-effect waves-light">Upgrade to Pro</a>
                    <ol class="breadcrumb">
                        <li><a href="#">Dashboard</a></li>
                    </ol>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- row -->
            <div class="row">
                <!--col -->
                <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                    <div class="white-box">
                        <div class="col-in row">
                            <div class="col-md-6 col-sm-6 col-xs-6"> <i data-icon="E" class="linea-icon linea-basic"></i>
                                <h5 class="text-muted vb">MYNEW CLIENTS</h5> </div>
                            <div class="col-md-6 col-sm-6 col-xs-6">
                                <h3 class="counter text-right m-t-15 text-danger">23</h3> </div>
                            <div class="col-md-12 col-sm-12 col-xs-12">
                                <div class="progress">
                                    <div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width: 40%"> <span class="sr-only">40% Complete (success)</span> </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.col -->
                <!--col -->
                <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                    <div class="white-box">
                        <div class="col-in row">
                            <div class="col-md-6 col-sm-6 col-xs-6"> <i class="linea-icon linea-basic" data-icon="&#xe01b;"></i>
                                <h5 class="text-muted vb">NEW PROJECTS</h5> </div>
                            <div class="col-md-6 col-sm-6 col-xs-6">
                                <h3 class="counter text-right m-t-15 text-megna">169</h3> </div>
                            <div class="col-md-12 col-sm-12 col-xs-12">
                                <div class="progress">
                                    <div class="progress-bar progress-bar-megna" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width: 40%"> <span class="sr-only">40% Complete (success)</span> </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.col -->
                <!--col -->
                <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                    <div class="white-box">
                        <div class="col-in row">
                            <div class="col-md-6 col-sm-6 col-xs-6"> <i class="linea-icon linea-basic" data-icon="&#xe00b;"></i>
                                <h5 class="text-muted vb">NEW INVOICES</h5> </div>
                            <div class="col-md-6 col-sm-6 col-xs-6">
                                <h3 class="counter text-right m-t-15 text-primary">157</h3> </div>
                            <div class="col-md-12 col-sm-12 col-xs-12">
                                <div class="progress">
                                    <div class="progress-bar progress-bar-primary" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width: 40%"> <span class="sr-only">40% Complete (success)</span> </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
            <!--row -->
            <div class="row">
                <div class="col-md-12">
                    <div class="white-box">
                        <h3 class="box-title">Sales Difference</h3>
                        <ul class="list-inline text-right">
                            <li>
                                <h5><i class="fa fa-circle m-r-5" style="color: #dadada;"></i>Site A View</h5>
                            </li>
                            <li>
                                <h5><i class="fa fa-circle m-r-5" style="color: #aec9cb;"></i>Site B View</h5>
                            </li>
                        </ul>
                        <div id="morris-area-chart2" style="height: 370px;"></div>
                    </div>
                </div>
            </div>

                <!--row -->
            <div class="row">
                <div class="col-md-12">
                    <div class="white-box">
                        <h3 class="box-title">Sales Difference</h3>
                        <ul class="list-inline text-right">
                            <li>
                                <a href="#" ><h5 style="color: #73a534;"><i class="fa fa-circle m-r-5" style="color: #73a534;"></i>Baixar Relatório</h5></a>
                            </li>
                        </ul>
                        <div id="morris-area-chart2" style="height: 370px; overflow: scroll;">
                            <table class="table display nowrap "  id="example" cellspacing="0">
                               <thead>
                                   <th>Franquia</th>
                                   <th>Mês</th>
                                   <th>Código</th>
                                   <th>Produto</th>
                                   <th>Saldo inicial</th>
                                   <th>Contagem Física</th>
                                   <th>Entrada</th>
                                   <th>Consumo do Mês</th>
                               </thead>
                                <tbody>
                                @foreach($controle as $cli)
                                    <tr>
                                        <td>{{$cli->franquia}}</td>
                                        <td>{{$cli->mes}}</td>
                                        <td>{{$cli->codigo}}</td>
                                        <td>{{$cli->produto}}</td>
                                        <td>{{$cli->saldo_inicial}}</td>
                                        <td>{{$cli->contagem_fisica}}</td>
                                        <td>{{$cli->qtd_entrada}}</td>
                                        <td>{{$cli->consumo}}</td>
                                    </tr>
                                @endforeach
                                </tbody>

                            </table>
                        </div>
                    </div>
                </div>
            </div>
		
		<div class="row">
                <div class="col-md-12">
                    <div class="white-box">
                        <h3 class="box-title">Saldo Inicial</h3>
                        <ul class="list-inline text-right">
                            <li>
                                <a href="#" ><h5 style="color: #73a534;"><i class="fa fa-circle m-r-5" style="color: #73a534;"></i>Baixar Relatório</h5></a>
                            </li>
                        </ul>
                        <div id="morris-area-chart2" style="height: 370px; overflow: scroll;">
                            <table class="table display nowrap "  id="sal_inicial" cellspacing="0">
                               <thead>
                                   <th>Franquia</th>
                                   <th>Mês</th>
                                   <th>Código</th>
                                   <th>Produto</th>
                                   <th>Saldo inicial</th>
                               </thead>
                                <tbody>
                                @foreach($saldo_inicial as $cli)
                                    <tr>
                                        <td>{{$cli->franquia}}</td>
                                        <td>{{$cli->mes}}</td>
                                        <td>{{$cli->codigo}}</td>
                                        <td>{{$cli->produto}}</td>
                                        <td>{{$cli->saldo_inicial}}</td>
                                    </tr>
                                @endforeach
                                </tbody>

                            </table>
                        </div>
                    </div>
                </div>
            </div>
		</div>

                <!--row -->



            <!-- Page Content -->
    <div id="page-wrapper">
        <div class="container-fluid">



        </div>
        <footer class="footer text-center">

            2017 © Copyright Logistica | PSI Moz. <a href="http://evidevi.com/" target="_blank">Powered by.: evidevi.com</a>
        </footer>
    </div>
    <!-- /#page-wrapper -->


    <script>
        $(document).ready(function() {
            $('#example').DataTable( {
                "scrollY": 200,
                "scrollX": true,
                dom: 'Bfrtip',
                buttons: [
                    'csv', 'excel', 'pdf', 'print'
                ]
            } );
			
			 $('#sal_inicial').DataTable( {
                "scrollY": 200,
                "scrollX": true,
                dom: 'Bfrtip',
                buttons: [
                    'csv', 'excel', 'pdf', 'print'
                ]
            } );
        } );
    </script>

@endsection()